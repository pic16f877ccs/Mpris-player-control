import St from 'gi://St';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import {DBusSenderChecker} from 'resource:///org/gnome/shell/misc/util.js';

import { MPRIS_PLAYERCTLD, MPRIS_PLAYER_STOPPED, MPRIS_PLAYER_IFACE_PATH, MPRIS_PLAYER_OBJECT_PATH,
    MPRIS_PLAYER_IFACE_XML, FREEDESKTOP_DBUS_INDEX, FREEDESKTOP_DBUS_IFACE_PATH,
    FREEDESKTOP_DBUS_OBJECT_PATH, FREEDESKTOP_DBUS_IFACE_XML } from './constants.js';

export default class ExampleExtension extends Extension {
    async enable() {
        this._indicator = new PanelMenu.Button(0.0, this.metadata.name, false);
        this._initPlayerControlBox();
        this._mprisPlayersNames = [];
        this._mprisPlayer = [];
        this._playerPauseHandler = null;
        this._playerPropertiesHandler = null;
        this._mprisProxyPlayer = Gio.DBusProxy.makeProxyWrapper(MPRIS_PLAYER_IFACE_XML);
        this._dbusSenderChecker = new DBusSenderChecker(['org.mpris.MediaPlayer2.Player.mpv']);

        if (false) {
            this._mprisPlayersNames = [MPRIS_PLAYERCTLD];
            this._addProxyPlayer();
        } else {
            this._dbusProxy = await new Promise((resolve, reject) => {
                Gio.DBusProxy.makeProxyWrapper(FREEDESKTOP_DBUS_IFACE_XML)(
                    Gio.DBus.session,
                    FREEDESKTOP_DBUS_IFACE_PATH,
                    FREEDESKTOP_DBUS_OBJECT_PATH,
                    (dbusProxy, dbusProxyError) => {
                        if (dbusProxyError === null) {
                                dbusProxy.ListNamesRemote((dbusNamesList, listNamesError, _fdList) => {
                                    if (listNamesError === null) {
                                        this._mprisPlayersNames = dbusNamesList[FREEDESKTOP_DBUS_INDEX] 
                                            .filter(element => element.startsWith(MPRIS_PLAYER_IFACE_PATH));

                                        if (this._mprisPlayersNames.length) {
                                            this._addProxyPlayer();
                                        }
                                    } else {
                                        console.warn(listNamesError);
                                    }
                                });

                                this._handlerProxyDBus = dbusProxy.connectSignal(
                                    'NameOwnerChanged',
                                    this._onNameOwnerChanged.bind(this)
                                );

                            this._initPlayerControlHandlers();

                            resolve(dbusProxy);
                        } else {
                            reject(dbusProxyError);
                        }
                    },
                    null,
                    Gio.DBusProxyFlags.NONE,
                );
            });
        }


        this._dbusSenderChecker._isSenderAllowed('org.mpris.MediaPlayer2.Player.mpv').then((v) => {
            console.log('$$$$$$$$$ ' + v + ' $$$$$$$$$$$$$$$$$$$');
        });
    }

    async _initPlayerControlHandlers() {
        this._playerPlayHandler = this._play_icon.connect('button-press-event', () => {
            this._playToPause();
        });

        this._playerForwardHandler = this._forward_icon.connect('button-press-event', async () => {
            try {
                await this._mprisPlayer.NextAsync();
                log("***** >>| *****");
            } catch (e) {
                log("***** XX *****");
            }
        });

        this._playerBackwardHandler = this._backward_icon.connect('button-press-event', async () => {
            try {
                await this._mprisPlayer.PreviousAsync();
                log("***** <<| *****");
            } catch (e) {
                log("***** XX *****");
            }
        });
    }

    _onNameOwnerChanged(_proxy, _nameOwner, [name, oldOwner, newOwner]) {
        if (name.startsWith(MPRIS_PLAYER_IFACE_PATH)) {
            if (newOwner) {
                this._mprisPlayersNames.push(name);
                console.log(`*****< Add Player name: ${name} >*****`);
                console.log(`*****< Player owner: ${newOwner} >*****`);

                if (this._mprisPlayersNames.length == 1) {
                    this._addProxyPlayer();
                    console.log(`*****< Create Player: ${name} >*****`);
                }

                return;
            }

            if (oldOwner) {
                this._mprisPlayersNames.splice(this._mprisPlayersNames.indexOf(name), 1);

                if (this._mprisPlayer.get_name_owner() === oldOwner) {
                    this._removeProxyPlayer();
                }

                if (this._mprisPlayersNames.length) {
                    this._addProxyPlayer();
                }
                console.log(`*****< Remove Player name: ${name} >*****`);
            }
        }
    }

    _removeProxyPlayer() {
        this._setPlayerInActive();

        if (this._playerPropertiesHandler !== null) { 
            this._mprisPlayer.disconnect(this._playerPropertiesHandler);
            this._playerPropertiesHandler = null;
        }

        this._mprisPlayer = null;
    }

    async _addProxyPlayer() {
        try {
            this._mprisPlayer = await this._mprisProxyPlayer(Gio.DBus.session, this._mprisPlayersNames[0], MPRIS_PLAYER_OBJECT_PATH);
            this._playerPropertiesHandlerInit();
            this._getPlaybackStatus();
        } catch (e) {
            log("***** Error add new Player *****");
        }
    }

    _getPlaybackStatus() {
        if (this._mprisPlayer.PlaybackStatus === 'Playing') {
            this._playToPause();
            this._setPlayerActive();
        } else if (this._mprisPlayer.PlaybackStatus === 'Paused') {
            this._pauseToPlay();
            this._setPlayerActive();
        } else if (this._mprisPlayer.PlaybackStatus === 'Stopped') {
            this._setPlayerInActive(MPRIS_PLAYER_STOPPED);
        } else {
            this._setPlayerInActive();
        }

    }

    _playerPropertiesHandlerInit() {
        if (this._playerPropertiesHandler !== null) { 
            this._mprisPlayer.disconnect(this._playerPropertiesHandler);
            this._playerPropertiesHandler = null;
        }

        this._playerPropertiesHandler = this._mprisPlayer.connect('g-properties-changed', (_proxy, changed, _invalidated) => {
            this._getPlaybackStatus();

            console.log(`%%%%%< Properties-changed-signal >%%%%% ${changed}`);
            console.log(`%%%%%< Player property PlaybackStatus>%%%%% ${this._mprisPlayer.PlaybackStatus}`);
            //const properties = changed.deepUnpack();
            //console.log(`Property Metadata: ${this._mprisPlayer.Metadata.deepUnpack()}`);
            //for (const [name, value] of Object.entries(properties))
            //    console.log(`Property ${name} set to ${value.unpack()}`);
            //console.log(`%%%%%< Properties-changed-invalidated >%%%%% ${_invalidated}`);
        });
    }

    _setPlayerActive(start = 0, end = 5) {
        [this._stop_icon, this._play_icon, this._pause_icon, this._forward_icon, this._backward_icon]
            .slice(start, end)
            .forEach(icon => { 
                if (!icon.get_reactive())
                    icon.set_reactive(true);
                if (!icon.get_can_focus())
                    icon.set_can_focus(true);
                if (!icon.get_track_hover())
                    icon.set_track_hover(true);
                if (icon.has_style_class_name('control-panel-icon-inactive'))
                    icon.remove_style_class_name('control-panel-icon-inactive');
            });
            log("[[[[[ " + this._mprisPlayer.PlaybackStatus + " ]]]]]");
    }

    _setPlayerInActive(start = 0, end = 5) {
        [this._stop_icon, this._play_icon, this._pause_icon, this._forward_icon, this._backward_icon]
            .slice(start, end)
            .forEach(icon => { 
                if (icon.get_reactive())
                    icon.set_reactive(false);
                if (icon.get_can_focus())
                    icon.set_can_focus(false);
                if (icon.get_track_hover())
                    icon.set_track_hover(false);
                if (!icon.has_style_class_name('control-panel-icon-inactive'))
                    icon.add_style_class_name('control-panel-icon-inactive');
            });
            log("[[[[[ " + this._mprisPlayer.PlaybackStatus + " ]]]]]");

        this._playOrPauseToStop();
    }

    _connectStop() {
        this._playerPauseHandler = this._pause_icon.connect('button-press-event', this._playPause.bind(this));
        log("***** == *****");
    }

    _connectPlay() {
        this._playerPlayHandler = this._play_icon.connect('button-press-event', this._playPause.bind(this));
        log("***** => *****");
    }

    _playToPause() {
        if (this._playerPlayHandler !== null) {
            this._play_icon.disconnect(this._playerPlayHandler);
            this._playerPlayHandler = null;
        }

        if (this._control_box.get_child_at_index(1) === this._play_icon) { 
            this._control_box.replace_child(this._play_icon, this._pause_icon);
            this._connectStop();
        } else if (this._control_box.get_child_at_index(1) === this._stop_icon) { 
            this._control_box.replace_child(this._stop_icon, this._pause_icon);
            this._setPlayerActive();
            this._connectStop();
        }
    }

    _pauseToPlay() {
        if (this._playerPauseHandler !== null) { 
            this._pause_icon.disconnect(this._playerPauseHandler);
            this._playerPauseHandler = null;
        }

        if (this._control_box.get_child_at_index(1) === this._pause_icon) { 
            this._control_box.replace_child(this._pause_icon, this._play_icon);
            this._connectPlay();
        } else if (this._control_box.get_child_at_index(1) === this._stop_icon) { 
            this._control_box.replace_child(this._stop_icon, this._play_icon);
            this._setPlayerActive();
            this._connectPlay();
        }
    }

    _playOrPauseToStop() {
        if (this._playerPauseHandler !== null) { 
            this._pause_icon.disconnect(this._playerPauseHandler);
            this._playerPauseHandler = null;
        }

        if (this._playerPlayHandler !== null) {
            this._play_icon.disconnect(this._playerPlayHandler);
            this._playerPlayHandler = null;
        }

        if (this._control_box.get_child_at_index(1) === this._pause_icon) { 
            this._control_box.replace_child(this._pause_icon, this._stop_icon);
        } else if (this._control_box.get_child_at_index(1) === this._play_icon) { 
            this._control_box.replace_child(this._play_icon, this._stop_icon);
        }
    }

    async _playPause() {
        if (this._mprisPlayer) {
            await this._mprisPlayer.PlayPauseAsync();
        }
    }

    _initPlayerControlBox() {
        const indicator_box = new St.BoxLayout({
            orientation: Clutter.Orientation.HORIZONTAL,
            x_expand: true,
            y_expand: true,
        });

        this._control_box = new St.BoxLayout({
            orientation: Clutter.Orientation.HORIZONTAL,
            x_expand: true,
            y_expand: true,
        });

        this._forward_icon = new St.Icon({
            icon_name: 'media-skip-forward-symbolic',
            style_class: 'control-panel-icon',
            reactive: false,
            track_hover: false,
            can_focus: false,
        });
        this._forward_icon.add_style_class_name('control-panel-icon-inactive');

        this._backward_icon = new St.Icon({
            icon_name: 'media-skip-backward-symbolic',
            style_class: 'control-panel-icon',
            reactive: false,
            track_hover: false,
            can_focus: false,
        });
        this._backward_icon.add_style_class_name('control-panel-icon-inactive');

        this._play_icon = new St.Icon({
            icon_name: 'media-playback-start-symbolic',
            style_class: 'control-panel-icon',
            reactive: false,
            track_hover: false,
            can_focus: false,
        });
        this._play_icon.add_style_class_name('control-panel-icon-inactive');

        this._pause_icon = new St.Icon({
            icon_name: 'media-playback-pause-symbolic',
            style_class: 'control-panel-icon',
            reactive: false,
            track_hover: false,
            can_focus: false,
        });
        this._pause_icon.add_style_class_name('control-panel-icon-inactive');

        this._stop_icon = new St.Icon({
            icon_name: 'media-playback-stop-symbolic',
            style_class: 'control-panel-icon',
            reactive: false,
            track_hover: false,
            can_focus: false,
        });
        this._stop_icon.add_style_class_name('control-panel-icon-inactive');

        this._control_box.add_child(this._backward_icon);
        this._control_box.add_child(this._stop_icon);
        this._control_box.add_child(this._forward_icon);

        indicator_box.add_child(this._control_box);
        this._indicator.add_child(indicator_box);
        Main.panel.addToStatusArea(this.uuid, this._indicator);
    }

    disable() {
        if (this._handlerProxyDBus !== null) {
            this._dbusProxy.disconnectSignal(this._handlerProxyDBus);
            this._handlerProxyDBus = null;
        }

        if (this._playerPlayHandler !== null) {
            this._play_icon.disconnect(this._playerPlayHandler);
            this._playerPlayHandler = null;
        }

        if (this._playerPauseHandler !== null) { 
            this._pause_icon.disconnect(this._playerPauseHandler);
            this._playerPauseHandler = null;
        }

        if (this._playerForwardHandler !== null) { 
            this._forward_icon.disconnect(this._playerForwardHandler);
            this._playerForwardHandler = null;
        }

        if (this._playerBackwardHandler !== null) { 
            this._backward_icon.disconnect(this._playerBackwardHandler);
            this._playerBackwardHandler = null;
        }

        if (this._playerPropertiesHandler !== null) { 
            this._mprisPlayer.disconnect(this._playerPropertiesHandler);
            this._playerPropertiesHandler = null;
        }

        this._indicator?.destroy();
        this._indicator = null;
    }
}

        //player.play_from_file(soundFilePath, 'Notification sound', null);

        //this._separator = new St.Widget({
        //    style_class: 'popup-separator-menu-item-separator',
        //    x_expand: true,
        //    y_expand: true,
        //    y_align: Clutter.ActorAlign.CENTER,
        //});


        //box.add_child(this._separator);

        //const icon_buttom = new St.Icon({
        //    icon_name: 'face-laugh-symbolic',
        //    style_class: 'system-status-icon',
        //});
        //box.add_child(icon_buttom);


        //let expander = new St.Bin({
        //    style_class: 'popup-menu-item-expander',
        //    x_expand: true,
        //});
        //this._indicator.add_child(expander);
            //const soundFilePath = Gio.File.new_for_path('/home/sandu/Musik/sounds/Atlantis [zLtgYfPQshM].mp3');
            //const player = global.display.get_sound_player();
            //log("|||||||||||| -> " + soundFilePath);
            //player.play_from_file(soundFilePath, 'Notification sound', null);
    //_manageForwardIcon(showIcon) {
    //    if (showIcon) 
    //        if (this._forward_icon == null) {
    //            this._forward_icon = new St.Icon({
    //                icon_name: 'media-skip-backward-symbolic',
    //                style_class: 'stop-icon',
    //                reactive: true,
    //                track_hover: true,
    //                can_focus: true,
    //            });

    //            this._control_box.add_child(this._forward_icon);
    //        }

    //        if (this._playerPauseHandler == null) { 
    //            this._palyerForwardHandler = this._forward_icon.connect('button-press-event', () => {

    //                log("|||||||||||| >>| ");
    //            });
    //        }
    //    } else {
    //       this._pause_icon.disconnect(this._playerPauseHandler);
    //        this._playerPauseHandler = null;
    //    }

    //}

    //_connectBackward(flag) {
    //    this._playerBackwardHandler = this._backward_icon.connect('button-press-event', () => {
    //        log("|||||||||||| <<| ");
    //    });
    //}

        //this._playerProxySync = new Gio.DBusProxy.new_sync(
        //    Gio.DBus.session,
        //    Gio.DBusProxyFlags.NONE,
        //    Gio.DBusNodeInfo.new_for_xml(IFACE_PLAYER).interfaces[0],
        //    BUS_NAME,
        //    OBJECT_PATH,
        //    "org.mpris.MediaPlayer2.Player",
        //    null
        //);

        //this._control_box.set_reactive(false); // prevents pointer/keyboard events 
        //this._control_box.set_can_focus(false); // prevents keyboard focus
        //this._control_box.visible = false;

            //style_class: 'system-status-icon',
                    //if (this._propertiesHandler === null) {
                    //    this._propertiesHandler = this._playerProxyClass(
                    //        Gio.DBus.session,
                    //        this._dbusIfaceProxy.ListNamesSync()[ORG_FREEDESKTOP_DBUS].filter(element => element.startsWith("org.mpris.MediaPlayer2"))[0],
                    //        OBJECT_PATH,
                    //    ).connect('g-properties-changed', (proxy, _changed, _invalidated) => {

                    //        console.log(`PlaybackStatus: ${proxy.PlaybackStatus}`);
                    //    });
                    //}



        //const dbusMpv = this._dbusIfaceProxy.ListNamesSync()[ORG_FREEDESKTOP_DBUS]
        //    .filter(element => element.startsWith("org.mpris.MediaPlayer2"));

        //if (dbusMpv.length !== 0) {
        //    log("***** " + dbusMpv[0] + " *****");
        //    this._control_box.get_children()
        //        .forEach(child => { 
        //              child.set_reactive(true);
        //              child.set_can_focus(true);
        //              child.track_hover = true;
        //              child.remove_style_class_name('control-panel-icon-inactive');
        //        });
        //}

        //const dbusMpv = this._dbusIfaceProxy.ListNamesSync()[ORG_FREEDESKTOP_DBUS]
        //    .filter(element => element.startsWith("org.mpris.MediaPlayer2"))[0];

        //log("*****>> " + dbusMpv + " <<******");

        //try {
        //    const playerProxy = this._playerProxyClass(Gio.DBus.session, dbusMpv, OBJECT_PATH);
        //    playerProxy.PlayPauseSync();

        //    log("***** => *****");
        //} catch (e) {
        //    log("***** XX *****");
        //}
            //try {
            //    this._mprisPlayer = this._playerProxyClass(Gio.DBus.session, this._mprisPlayersNames[0], OBJECT_PATH)
            //    this._playerPropertiesHandler();

            //    this._setPlayerActive();

            //    log("||||||||||||||||| Create new proxy Player owner" + this._owner + " |||||||||||||||||");
            //} catch (e) {
            //    log("||||||||||||||||| Error create new proxy Player ||||||||||||||||");
            //}
//this._mediaPlayerProxyClass = Gio.DBusProxy.makeProxyWrapper(IFACE_MEDIA_PLAYER_2);
//const IFACE_MEDIA_PLAYER_2 = `
//<node>
//    <interface name="org.mpris.MediaPlayer2">
//    <property name="Identity" type="s" access="read"/>
//    </interface>
//</node>
//`;

        //this._handlerDBusIface = this._dbusIfaceProxy.connectSignal('NameOwnerChanged', (_proxy, _nameOwner, [name, oldOwner, newOwner]) => {
        //    if (name.startsWith(MPRIS_PLAYER_IFACE_PATH)) {
        //        if (newOwner) {
        //            this._mprisPlayersNames.push(name);
        //            console.log(`*****< Add Player name: ${name} >*****`);
        //            console.log(`*****< Player owner: ${newOwner} >*****`);

        //            if (this._mprisPlayersNames.length == 1) {
        //                this._newDBusProxyPlayer();
        //                console.log(`*****< Create Player: ${name} >*****`);
        //            }

        //            return;
        //        }

        //        if (oldOwner) {
        //            if (this._mprisPlayer.get_name_owner() === oldOwner) {
        //                if (this._playerPropertiesHandler !== null) { 
        //                    this._mprisPlayer.disconnect(this._playerPropertiesHandler);
        //                    this._playerPropertiesHandler = null;
        //                }

        //                console.log(`*****< Delete Player: ${name} >*****`);
        //                console.log(`*****< Player Owner: ${oldOwner} >*****`);
        //                this._mprisPlayer = null;
        //                this._mprisPlayersNames.splice(this._mprisPlayersNames.indexOf(name), 1);
        //                this._setPlayerInActive();

        //                if (this._mprisPlayersNames.length) {
        //                    this._newDBusProxyPlayer();
        //                    console.log(`*****< Create Player: ${name} >*****`);
        //                    console.log(`*****< Player owner: ${this._mprisPlayer.get_name_owner()} >*****`);
        //                }
        //            } else {
        //                this._mprisPlayersNames.splice(this._mprisPlayersNames.indexOf(name), 1);
        //            }
        //            console.log(`*****< Remove Player name: ${name} >*****`);
        //        }
        //    }
        //});
                    //console.log(`*****< Create Player: ${name} >*****`);
                    //console.log(`*****< Player owner: ${this._mprisPlayer.get_name_owner()} >*****`);
        //console.log(`*****< Delete Player: ${name} >*****`);
        //console.log(`*****< Player Owner: ${oldOwner} >*****`);
            //if (this._mprisPlayer.PlaybackStatus === 'Playing') {
            //    this._playToPause();
            //} else if (this._mprisPlayer.PlaybackStatus === 'Paused') {
            //    this._pauseToPlay();
            //} else if (this._mprisPlayer.PlaybackStatus === 'Stopped') {
            //    this._setPlayerInActive(MPRIS_PLAYER_STOPPED);
            //}
            //const dbusIfaceProxy = Gio.DBusProxy.makeProxyWrapper(FREEDESKTOP_DBUS_IFACE_XML);
                //dbusIfaceProxy(
        //this._initProxyPlayer().then((value) => {
        //    this._mprisPlayersNames = value.filter(element => element.startsWith(MPRIS_PLAYER_IFACE_PATH));

        //    if (this._mprisPlayersNames.length) {
        //        this._addProxyPlayer();
        //    }
        //});

        //try {
        //    this._mprisPlayersNames = await this._dbusProxy.ListNamesAsync()[FREEDESKTOP_DBUS_INDEX]
        //        .filter(element => element.startsWith(MPRIS_PLAYER_IFACE_PATH));
        //    if (this._mprisPlayersNames.length) {
        //        this._addProxyPlayer();
        //    }
        //} catch (error) {
        //    console.warn(error);
        //}
            //[FREEDESKTOP_DBUS_INDEX]

        //this._playerPlayHandler = this._play_icon.connect('button-press-event', () => {
        //    this._playToPause();
        //});

        //this._playerForwardHandler = this._forward_icon.connect('button-press-event', async () => {
        //    try {
        //        await this._mprisPlayer.NextAsync();
        //        log("***** >>| *****");
        //    } catch (e) {
        //        log("***** XX *****");
        //    }
        //});

        //this._playerBackwardHandler = this._backward_icon.connect('button-press-event', async () => {
        //    try {
        //        await this._mprisPlayer.PreviousAsync();
        //        log("***** <<| *****");
        //    } catch (e) {
        //        log("***** XX *****");
        //    }
        //});
