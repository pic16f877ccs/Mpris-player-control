export const MPRIS_PLAYERCTLD = "org.mpris.MediaPlayer2.playerctld";
export const MPRIS_PLAYER_STOPPED = 1;
export const MPRIS_PLAYER_IFACE_PATH = "org.mpris.MediaPlayer2"; 
export const MPRIS_PLAYER_OBJECT_PATH = "/org/mpris/MediaPlayer2"; 
export const MPRIS_PLAYER_IFACE_XML = `
<node>
    <interface name="org.mpris.MediaPlayer2.Player">
        <method name="PlayPause"/>
        <method name="Next"/>
        <method name="Previous"/>
        <property name="CanGoNext" type="b" access="read"/>
        <property name="CanGoPrevious" type="b" access="read"/>
        <property name="CanPlay" type="b" access="read"/>
        <property name="Metadata" type="a{sv}" access="read"/>
        <property name="PlaybackStatus" type="s" access="read"/>
    </interface>
</node>`;

export const FREEDESKTOP_DBUS_INDEX = 0;
export const FREEDESKTOP_DBUS_IFACE_PATH = "org.freedesktop.DBus";
export const FREEDESKTOP_DBUS_OBJECT_PATH = "/org/freedesktop/DBus";
export const FREEDESKTOP_DBUS_IFACE_XML = `
<node>
    <interface name="org.freedesktop.DBus">
        <method name="ListNames">
            <arg type="as" direction="out" name="names"/>
        </method>
        <method name="GetConnectionUnixProcessID">
            <arg type="s" direction="in"/>
            <arg type="u" direction="out"/>
        </method>
        <signal name="NameOwnerChanged">
            <arg type="s" direction="out" name="name"/>
            <arg type="s" direction="out" name="oldOwner"/>
            <arg type="s" direction="out" name="newOwner"/>
        </signal>
    </interface>
</node>`;
